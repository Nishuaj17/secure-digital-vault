package com.example.securedigitalvault.data.repository;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.PhotoDao;
import com.example.securedigitalvault.data.local.entity.PhotoEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.security.SecureFileManager;
import com.example.securedigitalvault.ui.photos.DecryptedPhoto;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PhotoRepository
 *
 * Coordinates between PhotoDao (metadata only) and SecureFileManager
 * (encrypted file bytes on disk). Photo bytes are never stored in the
 * database itself — only a filename reference.
 */
public class PhotoRepository {

    public interface PhotoCallback {
        void onResult(DecryptedPhoto photo);
    }

    public interface SimpleCallback {
        void onComplete(boolean success);
    }

    private final Context appContext;
    private final PhotoDao photoDao;
    private final SecureFileManager secureFileManager;
    private final ExecutorService executorService;

    public PhotoRepository(Context context) {
        this.appContext = context.getApplicationContext();
        VaultDatabase database = VaultDatabase.getInstance(appContext);
        this.photoDao = database.photoDao();
        CryptoManager cryptoManager = new CryptoManager(new KeystoreManager());
        this.secureFileManager = new SecureFileManager(cryptoManager);
        this.executorService = Executors.newSingleThreadExecutor();
    }

    /**
     * Returns photo METADATA only (id, name, date) — fast, no
     * decryption needed. The grid adapter requests decrypted image
     * bytes separately, per visible item, via decryptPhotoByIdAsync().
     */
    public LiveData<List<PhotoEntity>> getAllPhotoMetadata() {
        return photoDao.getAllPhotos();
    }

    public LiveData<Integer> getPhotoCountLive() {
        return photoDao.getPhotoCountLive();
    }

    public void insertPhoto(Uri sourcePhotoUri, SimpleCallback callback) {
        executorService.execute(() -> {
            boolean success = true;
            try {
                String fileName = secureFileManager.encryptAndStoreFile(appContext, sourcePhotoUri, SecureFileManager.DIR_PHOTOS);                PhotoEntity entity = new PhotoEntity(
                        "Photo", fileName, 0, System.currentTimeMillis());
                photoDao.insert(entity);
            } catch (IOException e) {
                success = false;
            }
            boolean finalSuccess = success;
            new Handler(Looper.getMainLooper()).post(() -> callback.onComplete(finalSuccess));
        });
    }

    public void deletePhoto(int id) {
        executorService.execute(() -> {
            PhotoEntity entity = photoDao.getPhotoById(id);
            if (entity != null) {
                secureFileManager.deleteEncryptedFile(appContext, entity.encryptedFileName, SecureFileManager.DIR_PHOTOS);                photoDao.delete(entity);
            }
        });
    }

    /**
     * Decrypts one photo's bytes for display. Called by the grid
     * adapter/viewer screen on demand rather than decrypting every
     * photo up front.
     */
    public void decryptPhotoByIdAsync(int id, PhotoCallback callback) {
        executorService.execute(() -> {
            PhotoEntity entity = photoDao.getPhotoById(id);
            Handler mainHandler = new Handler(Looper.getMainLooper());

            if (entity == null) {
                mainHandler.post(() -> callback.onResult(null));
                return;
            }

            try {
                byte[] imageBytes = secureFileManager.decryptFileBytes(appContext, entity.encryptedFileName, SecureFileManager.DIR_PHOTOS);                DecryptedPhoto decrypted = new DecryptedPhoto(
                        entity.id, entity.displayName, entity.dateAdded, imageBytes);
                mainHandler.post(() -> callback.onResult(decrypted));
            } catch (IOException e) {
                mainHandler.post(() -> callback.onResult(null));
            }
        });
    }
}


