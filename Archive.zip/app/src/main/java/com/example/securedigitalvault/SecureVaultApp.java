package com.example.securedigitalvault;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;

import com.example.securedigitalvault.data.prefs.AppPreferences;
import com.example.securedigitalvault.ui.auth.LockScreenActivity;
import com.example.securedigitalvault.ui.onboarding.EnableBiometricActivity;
import com.example.securedigitalvault.ui.onboarding.SetupPinActivity;
import com.example.securedigitalvault.ui.splash.SplashActivity;

/**
 * SecureVaultApp
 *
 * Tracks whether the app is currently in the foreground or background
 * across ALL Activities, and enforces the user's configured auto-lock
 * timeout. When the app returns to the foreground after being fully
 * backgrounded for longer than the configured duration, the user is
 * redirected to LockScreenActivity before they can see any vault
 * content again.
 *
 * WHY THIS APPROACH: Android has no single "app resumed after being
 * backgrounded" callback — only individual Activity lifecycle events.
 * By counting how many Activities are currently started, we can
 * detect the transition from "zero Activities visible" (truly
 * backgrounded) to "an Activity became visible again" (foregrounded),
 * which is what we need to evaluate the auto-lock timeout accurately
 * even as the user navigates between different screens inside the app
 * (which also triggers individual onStop/onStart calls, but WITHOUT
 * the count ever reaching zero, so it correctly does not trigger a
 * lock during normal in-app navigation).
 */
public class SecureVaultApp extends Application implements Application.ActivityLifecycleCallbacks {

    private int startedActivityCount = 0;
    private long backgroundedAtTimestamp = 0;
    private Activity currentActivity = null;

    @Override
    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
    }

    @Override
    public void onActivityStarted(Activity activity) {
        currentActivity = activity;
        startedActivityCount++;

        boolean isReturningFromFullBackground = (startedActivityCount == 1) && (backgroundedAtTimestamp != 0);

        if (isReturningFromFullBackground && shouldEnforceLock(activity)) {
            enforceLock(activity);
        }
    }

    @Override
    public void onActivityStopped(Activity activity) {
        startedActivityCount--;
        if (startedActivityCount <= 0) {
            startedActivityCount = 0;
            backgroundedAtTimestamp = System.currentTimeMillis();
        }
    }

    /**
     * Decides whether returning to the foreground should trigger a
     * lock, based on the user's configured auto-lock duration and
     * whether the screen they're landing on is already part of the
     * authentication flow itself (to avoid redundant/looping redirects).
     */
    private boolean shouldEnforceLock(Activity activity) {
        if (isAuthFlowScreen(activity)) {
            return false;
        }

        AppPreferences appPreferences = new AppPreferences(getApplicationContext());
        if (!appPreferences.isSetupComplete()) {
            // Still in first-time setup — auto-lock doesn't apply yet.
            return false;
        }

        int autoLockMinutes = appPreferences.getAutoLockMinutes();
        long elapsedMillis = System.currentTimeMillis() - backgroundedAtTimestamp;

        if (autoLockMinutes <= 0) {
            // "Immediately" setting: any time in the background at all
            // triggers a lock.
            return true;
        }

        long thresholdMillis = autoLockMinutes * 60_000L;
        return elapsedMillis >= thresholdMillis;
    }

    private boolean isAuthFlowScreen(Activity activity) {
        return activity instanceof SplashActivity
                || activity instanceof SetupPinActivity
                || activity instanceof EnableBiometricActivity
                || activity instanceof LockScreenActivity;
    }

    private void enforceLock(Activity activity) {
        Intent intent = new Intent(activity, LockScreenActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        activity.startActivity(intent);
    }

    // The remaining lifecycle callbacks are required by the interface
    // but not needed for auto-lock logic.
    @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}
    @Override public void onActivityResumed(Activity activity) {}
    @Override public void onActivityPaused(Activity activity) {}
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}
    @Override public void onActivityDestroyed(Activity activity) {}
}


