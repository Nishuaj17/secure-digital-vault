package com.example.securedigitalvault.util;

import android.app.Activity;
import android.view.WindowManager;

/**
 * SecurityUtils
 *
 * FLAG_SECURE, when applied to a window, does two things:
 *   1. Blocks screenshots and screen recording while that screen is
 *      visible (the user gets a black screen or a system toast saying
 *      it's blocked, depending on Android version/OEM).
 *   2. Causes that screen's thumbnail in the Android Recent Apps
 *      switcher to appear blank/blacked out, instead of showing a
 *      snapshot of sensitive content.
 *
 * LIMITATIONS OF FLAG_SECURE (worth understanding, not oversold):
 * - It does NOT prevent someone from taking a photo of the screen
 *   with a second physical device's camera.
 * - It does NOT protect against screen-mirroring/casting on some
 *   older Android versions or specific OEM implementations that
 *   don't fully respect the flag.
 * - It only applies to the screen it's set on — every sensitive
 *   Activity needs to call this individually; it is not a global
 *   app-wide setting.
 */
public class SecurityUtils {

    public static void applySecureFlag(Activity activity) {
        activity.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
    }
}


