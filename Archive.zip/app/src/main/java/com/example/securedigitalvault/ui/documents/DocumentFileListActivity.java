package com.example.securedigitalvault.ui.documents;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.local.entity.DocumentFileEntity;
import com.example.securedigitalvault.data.repository.DocumentFileRepository;
import com.example.securedigitalvault.util.SecurityUtils;

import java.io.File;

/**
 * DocumentFileListActivity
 *
 * Lists imported documents, supports search, import via the Storage
 * Access Framework document picker, and securely opening a document
 * in an external viewer app using a FileProvider-scoped URI.
 */
public class DocumentFileListActivity extends AppCompatActivity
        implements DocumentFileListAdapter.OnDocumentFileActionListener {

    // Must exactly match the authority declared in AndroidManifest.xml.
    private static final String FILE_PROVIDER_AUTHORITY = "com.yourname.securevault.fileprovider";

    private RecyclerView recyclerView;
    private EditText searchInput;
    private TextView emptyStateText;

    private DocumentFileRepository documentFileRepository;
    private DocumentFileListAdapter adapter;

    private ActivityResultLauncher<String[]> documentPickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_document_file_list);

        documentFileRepository = new DocumentFileRepository(getApplicationContext());

        recyclerView = findViewById(R.id.documentRecyclerView);
        searchInput = findViewById(R.id.searchInput);
        emptyStateText = findViewById(R.id.emptyStateText);

        adapter = new DocumentFileListAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        registerDocumentPicker();

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.importButton).setOnClickListener(v ->
                documentPickerLauncher.launch(new String[]{"*/*"}));

        setupSearch();
        observeDocuments("");
    }

    private void registerDocumentPicker() {
        documentPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                selectedUri -> {
                    if (selectedUri == null) return;
                    Toast.makeText(this, "Encrypting and saving document...", Toast.LENGTH_SHORT).show();
                    documentFileRepository.insertDocument(selectedUri, success -> {
                        String message = success ? "Document saved securely" : "Failed to save document";
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    });
                });
    }

    private void setupSearch() {
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                observeDocuments(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void observeDocuments(String query) {
        if (query == null || query.trim().isEmpty()) {
            documentFileRepository.getAllDocuments().observe(this, this::renderList);
        } else {
            documentFileRepository.searchByFileName(query.trim()).observe(this, this::renderList);
        }
    }

    private void renderList(java.util.List<DocumentFileEntity> documents) {
        adapter.submitList(documents);
        emptyStateText.setVisibility(documents.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(documents.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onRowClick(DocumentFileEntity document) {
        Toast.makeText(this, "Decrypting for viewing...", Toast.LENGTH_SHORT).show();

        documentFileRepository.openDocumentSecurely(document.id, new DocumentFileRepository.OpenCallback() {
            @Override
            public void onReady(File tempFile) {
                openWithExternalViewer(tempFile);
            }

            @Override
            public void onError() {
                Toast.makeText(DocumentFileListActivity.this,
                        "Could not open this document.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openWithExternalViewer(File tempFile) {
        Uri contentUri = FileProvider.getUriForFile(this, FILE_PROVIDER_AUTHORITY, tempFile);

        Intent viewIntent = new Intent(Intent.ACTION_VIEW);
        viewIntent.setDataAndType(contentUri, getMimeTypeForFile(tempFile.getName()));
        viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(viewIntent);
        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(this, "No app found to open this file type.", Toast.LENGTH_SHORT).show();
        }
    }

    private String getMimeTypeForFile(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".pdf")) return "application/pdf";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".txt")) return "text/plain";
        return "*/*";
    }

    @Override
    public void onDeleteClick(DocumentFileEntity document) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this document?")
                .setMessage("This will permanently delete \"" + document.fileName + "\". This cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> documentFileRepository.deleteDocument(document.id))
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Best-effort cleanup of any temp decrypted files from this session.
        documentFileRepository.clearTempFiles();
    }
}


