package com.example.securedigitalvault.ui.passwords;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;

import java.util.ArrayList;
import java.util.List;

/**
 * PasswordListAdapter
 *
 * Displays a list of DecryptedPassword entries. Note: these objects
 * hold plaintext usernames/passwords in memory for as long as the
 * list screen is visible — this is expected since the whole point of
 * this screen is to let the user view and act on their saved
 * passwords, but it's worth remembering this screen should use
 * FLAG_SECURE (added in a later phase) to prevent it from appearing
 * in the Android recent-apps screenshot preview.
 */
public class PasswordListAdapter extends RecyclerView.Adapter<PasswordListAdapter.PasswordViewHolder> {

    public interface OnPasswordActionListener {
        void onRowClick(DecryptedPassword password);
        void onCopyClick(DecryptedPassword password);
        void onDeleteClick(DecryptedPassword password);
        void onFavoriteToggle(DecryptedPassword password);
    }

    private List<DecryptedPassword> passwordList = new ArrayList<>();
    private final OnPasswordActionListener listener;

    public PasswordListAdapter(OnPasswordActionListener listener) {
        this.listener = listener;
    }

    public void submitList(List<DecryptedPassword> newList) {
        this.passwordList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PasswordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_password_row, parent, false);
        return new PasswordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PasswordViewHolder holder, int position) {
        DecryptedPassword item = passwordList.get(position);

        holder.siteNameText.setText(item.siteName);
        holder.usernameText.setText(item.username.isEmpty() ? "(no username)" : item.username);

        holder.favoriteButton.setImageResource(
                item.isFavorite ? android.R.drawable.star_on : android.R.drawable.star_off);

        holder.itemView.setOnClickListener(v -> listener.onRowClick(item));
        holder.copyButton.setOnClickListener(v -> listener.onCopyClick(item));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClick(item));
        holder.favoriteButton.setOnClickListener(v -> listener.onFavoriteToggle(item));
    }

    @Override
    public int getItemCount() {
        return passwordList.size();
    }

    static class PasswordViewHolder extends RecyclerView.ViewHolder {
        TextView siteNameText;
        TextView usernameText;
        ImageButton copyButton;
        ImageButton deleteButton;
        ImageButton favoriteButton;

        PasswordViewHolder(@NonNull View itemView) {
            super(itemView);
            siteNameText = itemView.findViewById(R.id.rowSiteName);
            usernameText = itemView.findViewById(R.id.rowUsername);
            copyButton = itemView.findViewById(R.id.copyButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            favoriteButton = itemView.findViewById(R.id.favoriteButton);
        }
    }
}

