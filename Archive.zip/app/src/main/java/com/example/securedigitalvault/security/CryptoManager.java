package com.example.securedigitalvault.security;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * CryptoManager
 *
 * Provides AES-256-GCM encryption and decryption for all sensitive
 * vault data, using the Keystore-backed key from KeystoreManager.
 *
 * OUTPUT FORMAT:
 * encrypt() returns a single byte[] structured as:
 *   [ 12 bytes: IV ][ remaining bytes: ciphertext + GCM auth tag ]
 * This combined format is what gets stored directly in a Room
 * byte[] column or written to a file. decrypt() expects this same
 * format back.
 *
 * WHY GCM MODE SPECIFICALLY:
 * GCM (Galois/Counter Mode) is an "authenticated encryption" mode.
 * Beyond just making data unreadable, it also embeds an authentication
 * tag that lets decrypt() detect if the ciphertext was tampered with
 * or corrupted — decryption will throw an exception rather than
 * silently returning garbled or manipulated data. This matters for a
 * vault app: we want corruption or tampering to fail loudly, not
 * quietly hand back broken data that looks superficially valid.
 *
 * IV / NONCE HANDLING:
 * A fresh random IV is generated for every single encryption call.
 * The IV is not secret — it's fine for it to sit right next to the
 * ciphertext — but it must never be reused with the same key, which
 * is why we always generate a new one via SecureRandom rather than
 * a counter or fixed value.
 */
public class CryptoManager {

    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int IV_LENGTH_BYTES = 12;
    private static final int GCM_TAG_LENGTH_BITS = 128;

    private final KeystoreManager keystoreManager;

    public CryptoManager(KeystoreManager keystoreManager) {
        this.keystoreManager = keystoreManager;
    }

    /**
     * Encrypts raw bytes and returns [IV][ciphertext+tag] as one array.
     */
    public byte[] encrypt(byte[] plaintext) {
        try {
            SecretKey secretKey = keystoreManager.getOrCreateSecretKey();

            byte[] iv = generateRandomIv();
            GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec);

            byte[] ciphertext = cipher.doFinal(plaintext);

            // Combine IV + ciphertext into a single array for storage.
            byte[] combined = new byte[iv.length + ciphertext.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(ciphertext, 0, combined, iv.length, ciphertext.length);

            return combined;

        } catch (Exception e) {
            // Never include plaintext or key material in this message.
            throw new RuntimeException("Encryption failed.", e);
        }
    }

    /**
     * Convenience overload for encrypting a String (e.g. a password or
     * note's text content) instead of raw bytes.
     */
    public byte[] encryptString(String plaintext) {
        return encrypt(plaintext.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Decrypts a [IV][ciphertext+tag] blob produced by encrypt().
     * Throws if the data is corrupted, tampered with, or was encrypted
     * with a different key (e.g. after a key reset).
     */
    public byte[] decrypt(byte[] combined) {
        try {
            if (combined == null || combined.length <= IV_LENGTH_BYTES) {
                throw new IllegalArgumentException("Encrypted data is too short to be valid.");
            }

            byte[] iv = Arrays.copyOfRange(combined, 0, IV_LENGTH_BYTES);
            byte[] ciphertext = Arrays.copyOfRange(combined, IV_LENGTH_BYTES, combined.length);

            SecretKey secretKey = keystoreManager.getOrCreateSecretKey();
            GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec);

            return cipher.doFinal(ciphertext);

        } catch (Exception e) {
            // This deliberately catches GCM authentication failures
            // (tampered/corrupted data) the same way as other errors —
            // the caller just needs to know decryption didn't succeed,
            // not the specific cryptographic reason, to avoid leaking
            // details that could help an attacker.
            throw new RuntimeException("Decryption failed. Data may be corrupted or tampered with.", e);
        }
    }

    /**
     * Convenience overload for decrypting back into a String.
     */
    public String decryptToString(byte[] combined) {
        return new String(decrypt(combined), StandardCharsets.UTF_8);
    }

    private byte[] generateRandomIv() {
        byte[] iv = new byte[IV_LENGTH_BYTES];
        new SecureRandom().nextBytes(iv);
        return iv;
    }
}


