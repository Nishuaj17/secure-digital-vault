package com.example.securedigitalvault.ui.recovery;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.RecoveryCodeRepository;
import com.example.securedigitalvault.util.SecurityUtils;

public class AddEditRecoveryCodeActivity extends AppCompatActivity {

    public static final String EXTRA_ENTRY_ID = "recovery_entry_id";
    private static final int NO_ID = -1;

    private TextView screenTitle;
    private EditText serviceNameInput, codesInput, notesInput;
    private TextView errorText;

    private RecoveryCodeRepository recoveryCodeRepository;
    private int editingId = NO_ID;
    private long originalCreatedAt = 0;
    private boolean originalIsFavorite = false;
    private int originalCategoryId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_add_edit_recovery_code);

        recoveryCodeRepository = new RecoveryCodeRepository(getApplicationContext());

        screenTitle = findViewById(R.id.screenTitle);
        serviceNameInput = findViewById(R.id.serviceNameInput);
        codesInput = findViewById(R.id.codesInput);
        notesInput = findViewById(R.id.notesInput);
        errorText = findViewById(R.id.errorText);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.saveButton).setOnClickListener(v -> handleSaveClicked());

        editingId = getIntent().getIntExtra(EXTRA_ENTRY_ID, NO_ID);
        if (editingId != NO_ID) {
            loadExisting(editingId);
        }
    }

    private void loadExisting(int id) {
        screenTitle.setText("Edit Recovery Codes");
        ((Button) findViewById(R.id.saveButton)).setText("Update");

        recoveryCodeRepository.getEntryByIdAsync(id, decrypted -> {
            if (decrypted == null) {
                Toast.makeText(this, "Could not load this entry.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            serviceNameInput.setText(decrypted.serviceName);
            codesInput.setText(decrypted.codes);
            notesInput.setText(decrypted.notes);
            originalCreatedAt = decrypted.createdAt;
            originalIsFavorite = decrypted.isFavorite;
            originalCategoryId = decrypted.categoryId;
        });
    }

    private void handleSaveClicked() {
        String serviceName = serviceNameInput.getText().toString().trim();
        String codes = codesInput.getText().toString().trim();
        String notes = notesInput.getText().toString().trim();

        if (serviceName.isEmpty()) {
            showError("Please enter a service or app name.");
            return;
        }
        if (codes.isEmpty()) {
            showError("Please enter at least one recovery code.");
            return;
        }

        if (editingId == NO_ID) {
            recoveryCodeRepository.insertEntry(serviceName, codes, notes, 0, false);
            Toast.makeText(this, "Recovery codes saved", Toast.LENGTH_SHORT).show();
        } else {
            DecryptedRecoveryCode updated = new DecryptedRecoveryCode(
                    editingId, serviceName, codes, notes, originalCategoryId,
                    originalIsFavorite, originalCreatedAt, System.currentTimeMillis());
            recoveryCodeRepository.updateEntry(updated);
            Toast.makeText(this, "Recovery codes updated", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
    }
}


