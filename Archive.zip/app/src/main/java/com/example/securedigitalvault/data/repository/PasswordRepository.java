package com.example.securedigitalvault.data.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.PasswordDao;
import com.example.securedigitalvault.data.local.entity.PasswordEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.ui.passwords.DecryptedPassword;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PasswordRepository
 *
 * The single point of contact between the UI layer and password
 * storage. Responsible for:
 *   - Encrypting sensitive fields (username, password, notes) before
 *     they are ever written to the database.
 *   - Decrypting them back into a DecryptedPassword after reading.
 *   - Running all write operations off the main thread.
 *
 * The UI (Activities/Fragments/ViewModels) should NEVER construct a
 * PasswordEntity or call CryptoManager directly — always go through
 * this class.
 */
public class PasswordRepository {

    private final PasswordDao passwordDao;
    private final CryptoManager cryptoManager;
    private final ExecutorService executorService;

    public PasswordRepository(Context context) {
        VaultDatabase database = VaultDatabase.getInstance(context);
        this.passwordDao = database.passwordDao();
        this.cryptoManager = new CryptoManager(new KeystoreManager());
        this.executorService = Executors.newSingleThreadExecutor();
    }

    /**
     * Returns a LiveData list of decrypted passwords, ready for display.
     * Uses Transformations.map so the UI automatically gets updated,
     * decrypted data any time the underlying table changes — no manual
     * refresh logic needed.
     */
    public LiveData<List<DecryptedPassword>> getAllPasswords() {
        return Transformations.map(passwordDao.getAllPasswords(), this::decryptList);
    }

    public LiveData<Integer> getPasswordCountLive() {
        return passwordDao.getPasswordCountLive();
    }

    /**
     * Encrypts and inserts a new password entry. Runs on a background
     * thread since Room does not allow writes on the main thread.
     */
    public void insertPassword(String siteName, String username, String password,
                               String url, String notes, int categoryId, boolean isFavorite) {
        executorService.execute(() -> {
            long now = System.currentTimeMillis();

            byte[] encryptedUsername = cryptoManager.encryptString(username);
            byte[] encryptedPassword = cryptoManager.encryptString(password);
            byte[] encryptedNotes = cryptoManager.encryptString(notes != null ? notes : "");

            PasswordEntity entity = new PasswordEntity(
                    siteName, url, categoryId, isFavorite, now, now,
                    encryptedUsername, encryptedPassword, encryptedNotes);

            passwordDao.insert(entity);
        });
    }

    /**
     * Encrypts and updates an existing password entry. The caller
     * provides a DecryptedPassword (plaintext) with its id already set
     * to the entry being edited.
     */
    public void updatePassword(DecryptedPassword decrypted) {
        executorService.execute(() -> {
            byte[] encryptedUsername = cryptoManager.encryptString(decrypted.username);
            byte[] encryptedPassword = cryptoManager.encryptString(decrypted.password);
            byte[] encryptedNotes = cryptoManager.encryptString(
                    decrypted.notes != null ? decrypted.notes : "");

            PasswordEntity entity = new PasswordEntity(
                    decrypted.siteName, decrypted.url, decrypted.categoryId,
                    decrypted.isFavorite, decrypted.createdAt, System.currentTimeMillis(),
                    encryptedUsername, encryptedPassword, encryptedNotes);
            entity.id = decrypted.id;

            passwordDao.update(entity);
        });
    }

    /**
     * Deletes a password entry by id. We fetch the full entity first
     * since Room's @Delete matches rows by their full object identity
     * (though in practice matching by primary key is sufficient here).
     */
    public void deletePassword(int id) {
        executorService.execute(() -> {
            PasswordEntity entity = passwordDao.getPasswordById(id);
            if (entity != null) {
                passwordDao.delete(entity);
            }
        });
    }

    public interface PasswordCallback {
        void onResult(DecryptedPassword password);
    }

    public void getPasswordByIdAsync(int id, PasswordCallback callback) {
        executorService.execute(() -> {
            PasswordEntity entity = passwordDao.getPasswordById(id);
            if (entity == null) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> callback.onResult(null));
                return;
            }
            String username = cryptoManager.decryptToString(entity.encryptedUsername);
            String password = cryptoManager.decryptToString(entity.encryptedPassword);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);

            DecryptedPassword decrypted = new DecryptedPassword(
                    entity.id, entity.siteName, username, password, entity.url, notes,
                    entity.categoryId, entity.isFavorite, entity.createdAt, entity.updatedAt);

            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> callback.onResult(decrypted));
        });
    }

    /**
     * Decrypts a full list of PasswordEntity objects into
     * DecryptedPassword objects for display.
     */
    private List<DecryptedPassword> decryptList(List<PasswordEntity> entities) {
        List<DecryptedPassword> decryptedList = new ArrayList<>();

        for (PasswordEntity entity : entities) {
            String username = cryptoManager.decryptToString(entity.encryptedUsername);
            String password = cryptoManager.decryptToString(entity.encryptedPassword);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);

            decryptedList.add(new DecryptedPassword(
                    entity.id, entity.siteName, username, password, entity.url, notes,
                    entity.categoryId, entity.isFavorite, entity.createdAt, entity.updatedAt));
        }

        return decryptedList;
    }
    public void toggleFavorite(int id, boolean isFavorite) {
        executorService.execute(() -> passwordDao.updateFavoriteStatus(id, isFavorite));
    }
}


