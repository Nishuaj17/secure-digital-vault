package com.example.securedigitalvault.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.DocumentIdDao;
import com.example.securedigitalvault.data.local.entity.DocumentIdEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.ui.documents.DecryptedDocumentId;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DocumentIdRepository {

    public interface DocumentCallback {
        void onResult(DecryptedDocumentId document);
    }

    private final DocumentIdDao documentDao;
    private final CryptoManager cryptoManager;
    private final ExecutorService executorService;

    public DocumentIdRepository(Context context) {
        VaultDatabase database = VaultDatabase.getInstance(context);
        this.documentDao = database.documentIdDao();
        this.cryptoManager = new CryptoManager(new KeystoreManager());
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<DecryptedDocumentId>> getAllDocuments() {
        return Transformations.map(documentDao.getAllDocuments(), this::decryptList);
    }

    public LiveData<Integer> getDocumentCountLive() {
        return documentDao.getDocumentCountLive();
    }

    public void insertDocument(String name, String type, String number, String issueDate,
                               String expiryDate, String notes, int categoryId, boolean isFavorite) {
        executorService.execute(() -> {
            long now = System.currentTimeMillis();
            byte[] encryptedNumber = cryptoManager.encryptString(number);
            byte[] encryptedNotes = cryptoManager.encryptString(notes != null ? notes : "");
            DocumentIdEntity entity = new DocumentIdEntity(
                    name, type, issueDate, expiryDate, categoryId, isFavorite,
                    now, now, encryptedNumber, encryptedNotes);
            documentDao.insert(entity);
        });
    }

    public void updateDocument(DecryptedDocumentId decrypted) {
        executorService.execute(() -> {
            byte[] encryptedNumber = cryptoManager.encryptString(decrypted.documentNumber);
            byte[] encryptedNotes = cryptoManager.encryptString(
                    decrypted.notes != null ? decrypted.notes : "");
            DocumentIdEntity entity = new DocumentIdEntity(
                    decrypted.documentName, decrypted.documentType, decrypted.issueDate,
                    decrypted.expiryDate, decrypted.categoryId, decrypted.isFavorite,
                    decrypted.createdAt, System.currentTimeMillis(), encryptedNumber, encryptedNotes);
            entity.id = decrypted.id;
            documentDao.update(entity);
        });
    }

    public void deleteDocument(int id) {
        executorService.execute(() -> {
            DocumentIdEntity entity = documentDao.getDocumentById(id);
            if (entity != null) {
                documentDao.delete(entity);
            }
        });
    }

    public void getDocumentByIdAsync(int id, DocumentCallback callback) {
        executorService.execute(() -> {
            DocumentIdEntity entity = documentDao.getDocumentById(id);
            Handler mainHandler = new Handler(Looper.getMainLooper());

            if (entity == null) {
                mainHandler.post(() -> callback.onResult(null));
                return;
            }

            String number = cryptoManager.decryptToString(entity.encryptedDocumentNumber);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);

            DecryptedDocumentId decrypted = new DecryptedDocumentId(
                    entity.id, entity.documentName, entity.documentType, number,
                    entity.issueDate, entity.expiryDate, notes, entity.categoryId,
                    entity.isFavorite, entity.createdAt, entity.updatedAt);

            mainHandler.post(() -> callback.onResult(decrypted));
        });
    }

    private List<DecryptedDocumentId> decryptList(List<DocumentIdEntity> entities) {
        List<DecryptedDocumentId> result = new ArrayList<>();
        for (DocumentIdEntity entity : entities) {
            String number = cryptoManager.decryptToString(entity.encryptedDocumentNumber);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);
            result.add(new DecryptedDocumentId(
                    entity.id, entity.documentName, entity.documentType, number,
                    entity.issueDate, entity.expiryDate, notes, entity.categoryId,
                    entity.isFavorite, entity.createdAt, entity.updatedAt));
        }
        return result;
    }
    public void toggleFavorite(int id, boolean isFavorite) {
        executorService.execute(() -> documentDao.updateFavoriteStatus(id, isFavorite));
    }
}


