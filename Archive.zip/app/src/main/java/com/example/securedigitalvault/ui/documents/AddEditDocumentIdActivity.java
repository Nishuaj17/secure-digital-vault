package com.example.securedigitalvault.ui.documents;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.DocumentIdRepository;
import com.example.securedigitalvault.util.SecurityUtils;

public class AddEditDocumentIdActivity extends AppCompatActivity {

    public static final String EXTRA_DOCUMENT_ID = "document_id";
    private static final int NO_ID = -1;

    private TextView screenTitle;
    private EditText nameInput, typeInput, numberInput, issueDateInput, expiryDateInput, notesInput;
    private TextView errorText;

    private DocumentIdRepository documentRepository;
    private int editingId = NO_ID;
    private long originalCreatedAt = 0;
    private boolean originalIsFavorite = false;
    private int originalCategoryId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_add_edit_document_id);

        documentRepository = new DocumentIdRepository(getApplicationContext());

        screenTitle = findViewById(R.id.screenTitle);
        nameInput = findViewById(R.id.nameInput);
        typeInput = findViewById(R.id.typeInput);
        numberInput = findViewById(R.id.numberInput);
        issueDateInput = findViewById(R.id.issueDateInput);
        expiryDateInput = findViewById(R.id.expiryDateInput);
        notesInput = findViewById(R.id.notesInput);
        errorText = findViewById(R.id.errorText);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.saveButton).setOnClickListener(v -> handleSaveClicked());

        editingId = getIntent().getIntExtra(EXTRA_DOCUMENT_ID, NO_ID);
        if (editingId != NO_ID) {
            loadExisting(editingId);
        }
    }

    private void loadExisting(int id) {
        screenTitle.setText("Edit ID / Document");
        ((Button) findViewById(R.id.saveButton)).setText("Update");

        documentRepository.getDocumentByIdAsync(id, decrypted -> {
            if (decrypted == null) {
                Toast.makeText(this, "Could not load this entry.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            nameInput.setText(decrypted.documentName);
            typeInput.setText(decrypted.documentType);
            numberInput.setText(decrypted.documentNumber);
            issueDateInput.setText(decrypted.issueDate);
            expiryDateInput.setText(decrypted.expiryDate);
            notesInput.setText(decrypted.notes);
            originalCreatedAt = decrypted.createdAt;
            originalIsFavorite = decrypted.isFavorite;
            originalCategoryId = decrypted.categoryId;
        });
    }

    private void handleSaveClicked() {
        String name = nameInput.getText().toString().trim();
        String type = typeInput.getText().toString().trim();
        String number = numberInput.getText().toString().trim();
        String issueDate = issueDateInput.getText().toString().trim();
        String expiryDate = expiryDateInput.getText().toString().trim();
        String notes = notesInput.getText().toString().trim();

        if (name.isEmpty()) {
            showError("Please enter a document name.");
            return;
        }
        if (number.isEmpty()) {
            showError("Please enter the document number.");
            return;
        }

        if (editingId == NO_ID) {
            documentRepository.insertDocument(name, type, number, issueDate, expiryDate, notes, 0, false);
            Toast.makeText(this, "Document saved", Toast.LENGTH_SHORT).show();
        } else {
            DecryptedDocumentId updated = new DecryptedDocumentId(
                    editingId, name, type, number, issueDate, expiryDate, notes,
                    originalCategoryId, originalIsFavorite, originalCreatedAt,
                    System.currentTimeMillis());
            documentRepository.updateDocument(updated);
            Toast.makeText(this, "Document updated", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
    }
}


