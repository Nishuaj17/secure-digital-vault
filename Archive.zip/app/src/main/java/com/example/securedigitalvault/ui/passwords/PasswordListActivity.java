package com.example.securedigitalvault.ui.passwords;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.PasswordRepository;
import com.example.securedigitalvault.util.ClipboardHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * PasswordListActivity
 *
 * Displays all saved passwords, with search-as-you-type filtering,
 * copy-to-clipboard, tap-to-edit, and delete with confirmation.
 *
 * SEARCH DESIGN NOTE: Filtering happens locally, in memory, on the
 * already-decrypted list this screen displays. This does not cause
 * any "extra" decryption beyond what the screen needs anyway (it must
 * decrypt every entry to display the list in the first place) — it
 * is different from, say, searching without ever loading the list,
 * which is why the DAO-level search-by-site-name query exists
 * separately for potential future use (e.g. a global search screen
 * that doesn't want to decrypt entries it won't display).
 */
public class PasswordListActivity extends AppCompatActivity
        implements PasswordListAdapter.OnPasswordActionListener {

    private RecyclerView recyclerView;
    private EditText searchInput;
    private TextView emptyStateText;
    private ImageButton backButton;

    private PasswordRepository passwordRepository;
    private PasswordListAdapter adapter;

    private List<DecryptedPassword> fullList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_list);

        passwordRepository = new PasswordRepository(getApplicationContext());

        recyclerView = findViewById(R.id.passwordRecyclerView);
        searchInput = findViewById(R.id.searchInput);
        emptyStateText = findViewById(R.id.emptyStateText);
        backButton = findViewById(R.id.backButton);

        adapter = new PasswordListAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        backButton.setOnClickListener(v -> finish());

        setupSearch();
        observePasswords();
    }

    private void observePasswords() {
        passwordRepository.getAllPasswords().observe(this, passwords -> {
            fullList = passwords;
            applyFilter(searchInput.getText().toString());
        });
    }

    private void setupSearch() {
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void applyFilter(String query) {
        if (query == null || query.trim().isEmpty()) {
            renderList(fullList);
            return;
        }

        String lowerQuery = query.toLowerCase(Locale.getDefault()).trim();
        List<DecryptedPassword> filtered = new ArrayList<>();
        for (DecryptedPassword p : fullList) {
            if (p.siteName.toLowerCase(Locale.getDefault()).contains(lowerQuery)) {
                filtered.add(p);
            }
        }
        renderList(filtered);
    }

    private void renderList(List<DecryptedPassword> list) {
        adapter.submitList(list);
        emptyStateText.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onRowClick(DecryptedPassword password) {
        Intent intent = new Intent(this, AddEditPasswordActivity.class);
        intent.putExtra(AddEditPasswordActivity.EXTRA_PASSWORD_ID, password.id);
        startActivity(intent);
    }

    @Override
    public void onCopyClick(DecryptedPassword password) {
        ClipboardHelper.copyWithAutoClear(this, "Password", password.password);
    }

    @Override
    public void onFavoriteToggle(DecryptedPassword password) {
        passwordRepository.toggleFavorite(password.id, !password.isFavorite);
    }

    @Override
    public void onDeleteClick(DecryptedPassword password) {
        new AlertDialog.Builder(this)
                .setTitle("Delete password?")
                .setMessage("This will permanently delete the entry for \"" + password.siteName + "\". This cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) ->
                        passwordRepository.deletePassword(password.id))
                .setNegativeButton("Cancel", null)
                .show();
    }
}

