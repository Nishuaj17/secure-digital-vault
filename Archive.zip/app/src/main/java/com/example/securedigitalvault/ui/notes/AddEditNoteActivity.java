package com.example.securedigitalvault.ui.notes;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.SecureNoteRepository;
import com.example.securedigitalvault.util.SecurityUtils;

public class AddEditNoteActivity extends AppCompatActivity {

    public static final String EXTRA_NOTE_ID = "note_id";
    private static final int NO_ID = -1;

    private TextView screenTitle;
    private EditText titleInput;
    private EditText contentInput;
    private TextView errorText;

    private SecureNoteRepository noteRepository;
    private int editingNoteId = NO_ID;
    private long originalCreatedAt = 0;
    private boolean originalIsFavorite = false;
    private int originalCategoryId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_add_edit_note);

        noteRepository = new SecureNoteRepository(getApplicationContext());

        screenTitle = findViewById(R.id.screenTitle);
        titleInput = findViewById(R.id.titleInput);
        contentInput = findViewById(R.id.contentInput);
        errorText = findViewById(R.id.errorText);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.saveButton).setOnClickListener(v -> handleSaveClicked());

        editingNoteId = getIntent().getIntExtra(EXTRA_NOTE_ID, NO_ID);
        if (editingNoteId != NO_ID) {
            loadExistingNote(editingNoteId);
        }
    }

    private void loadExistingNote(int id) {
        screenTitle.setText("Edit Note");
        ((android.widget.Button) findViewById(R.id.saveButton)).setText("Update Note");

        noteRepository.getNoteByIdAsync(id, decrypted -> {
            if (decrypted == null) {
                Toast.makeText(this, "Could not load this note.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            titleInput.setText(decrypted.title);
            contentInput.setText(decrypted.content);
            originalCreatedAt = decrypted.createdAt;
            originalIsFavorite = decrypted.isFavorite;
            originalCategoryId = decrypted.categoryId;
        });
    }

    private void handleSaveClicked() {
        String title = titleInput.getText().toString().trim();
        String content = contentInput.getText().toString();

        if (title.isEmpty()) {
            showError("Please enter a title.");
            return;
        }

        if (editingNoteId == NO_ID) {
            noteRepository.insertNote(title, content, 0, false);
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show();
        } else {
            DecryptedNote updated = new DecryptedNote(
                    editingNoteId, title, content, originalCategoryId,
                    originalIsFavorite, originalCreatedAt, System.currentTimeMillis());
            noteRepository.updateNote(updated);
            Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
    }
}


