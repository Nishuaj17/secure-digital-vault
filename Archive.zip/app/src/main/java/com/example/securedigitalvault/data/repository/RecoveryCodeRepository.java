package com.example.securedigitalvault.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.RecoveryCodeDao;
import com.example.securedigitalvault.data.local.entity.RecoveryCodeEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.ui.recovery.DecryptedRecoveryCode;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecoveryCodeRepository {

    public interface RecoveryCodeCallback {
        void onResult(DecryptedRecoveryCode entry);
    }

    private final RecoveryCodeDao recoveryCodeDao;
    private final CryptoManager cryptoManager;
    private final ExecutorService executorService;

    public RecoveryCodeRepository(Context context) {
        VaultDatabase database = VaultDatabase.getInstance(context);
        this.recoveryCodeDao = database.recoveryCodeDao();
        this.cryptoManager = new CryptoManager(new KeystoreManager());
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<DecryptedRecoveryCode>> getAllEntries() {
        return Transformations.map(recoveryCodeDao.getAllEntries(), this::decryptList);
    }

    public LiveData<Integer> getEntryCountLive() {
        return recoveryCodeDao.getEntryCountLive();
    }

    public void insertEntry(String serviceName, String codes, String notes,
                            int categoryId, boolean isFavorite) {
        executorService.execute(() -> {
            long now = System.currentTimeMillis();
            byte[] encryptedCodes = cryptoManager.encryptString(codes);
            byte[] encryptedNotes = cryptoManager.encryptString(notes != null ? notes : "");
            RecoveryCodeEntity entity = new RecoveryCodeEntity(
                    serviceName, categoryId, isFavorite, now, now, encryptedCodes, encryptedNotes);
            recoveryCodeDao.insert(entity);
        });
    }

    public void updateEntry(DecryptedRecoveryCode decrypted) {
        executorService.execute(() -> {
            byte[] encryptedCodes = cryptoManager.encryptString(decrypted.codes);
            byte[] encryptedNotes = cryptoManager.encryptString(
                    decrypted.notes != null ? decrypted.notes : "");
            RecoveryCodeEntity entity = new RecoveryCodeEntity(
                    decrypted.serviceName, decrypted.categoryId, decrypted.isFavorite,
                    decrypted.createdAt, System.currentTimeMillis(), encryptedCodes, encryptedNotes);
            entity.id = decrypted.id;
            recoveryCodeDao.update(entity);
        });
    }

    public void deleteEntry(int id) {
        executorService.execute(() -> {
            RecoveryCodeEntity entity = recoveryCodeDao.getEntryById(id);
            if (entity != null) {
                recoveryCodeDao.delete(entity);
            }
        });
    }

    public void getEntryByIdAsync(int id, RecoveryCodeCallback callback) {
        executorService.execute(() -> {
            RecoveryCodeEntity entity = recoveryCodeDao.getEntryById(id);
            Handler mainHandler = new Handler(Looper.getMainLooper());

            if (entity == null) {
                mainHandler.post(() -> callback.onResult(null));
                return;
            }

            String codes = cryptoManager.decryptToString(entity.encryptedCodes);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);
            DecryptedRecoveryCode decrypted = new DecryptedRecoveryCode(
                    entity.id, entity.serviceName, codes, notes, entity.categoryId,
                    entity.isFavorite, entity.createdAt, entity.updatedAt);

            mainHandler.post(() -> callback.onResult(decrypted));
        });
    }

    private List<DecryptedRecoveryCode> decryptList(List<RecoveryCodeEntity> entities) {
        List<DecryptedRecoveryCode> result = new ArrayList<>();
        for (RecoveryCodeEntity entity : entities) {
            String codes = cryptoManager.decryptToString(entity.encryptedCodes);
            String notes = cryptoManager.decryptToString(entity.encryptedNotes);
            result.add(new DecryptedRecoveryCode(entity.id, entity.serviceName, codes, notes,
                    entity.categoryId, entity.isFavorite, entity.createdAt, entity.updatedAt));
        }
        return result;
    }
    public void toggleFavorite(int id, boolean isFavorite) {
        executorService.execute(() -> recoveryCodeDao.updateFavoriteStatus(id, isFavorite));
    }
}


