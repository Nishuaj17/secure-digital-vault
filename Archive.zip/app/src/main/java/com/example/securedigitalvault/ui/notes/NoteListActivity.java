package com.example.securedigitalvault.ui.notes;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.SecureNoteRepository;

public class NoteListActivity extends AppCompatActivity implements NoteListAdapter.OnNoteActionListener {

    private RecyclerView recyclerView;
    private android.widget.TextView emptyStateText;
    private SecureNoteRepository noteRepository;
    private NoteListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);

        noteRepository = new SecureNoteRepository(getApplicationContext());

        recyclerView = findViewById(R.id.noteRecyclerView);
        emptyStateText = findViewById(R.id.emptyStateText);

        adapter = new NoteListAdapter(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.addButton).setOnClickListener(v ->
                startActivity(new Intent(this, AddEditNoteActivity.class)));

        noteRepository.getAllNotes().observe(this, notes -> {
            adapter.submitList(notes);
            emptyStateText.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
            recyclerView.setVisibility(notes.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    @Override
    public void onRowClick(DecryptedNote note) {
        Intent intent = new Intent(this, AddEditNoteActivity.class);
        intent.putExtra(AddEditNoteActivity.EXTRA_NOTE_ID, note.id);
        startActivity(intent);
    }

    @Override
    public void onFavoriteToggle(DecryptedNote note) {
        noteRepository.toggleFavorite(note.id, !note.isFavorite);
    }

    @Override
    public void onDeleteClick(DecryptedNote note) {
        new AlertDialog.Builder(this)
                .setTitle("Delete note?")
                .setMessage("This will permanently delete \"" + note.title + "\". This cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> noteRepository.deleteNote(note.id))
                .setNegativeButton("Cancel", null)
                .show();
    }
}

