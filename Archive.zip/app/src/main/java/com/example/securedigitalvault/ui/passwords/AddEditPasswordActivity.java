package com.example.securedigitalvault.ui.passwords;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.PasswordRepository;
import com.example.securedigitalvault.util.SecurityUtils;

/**
 * AddEditPasswordActivity
 *
 * Handles both creating a new password entry and editing an existing
 * one, based on whether an "password_id" extra is passed in via the
 * launching Intent. A value of -1 (the default) means "add new."
 *
 * SECURITY NOTE: We only ever pass a plain integer id through the
 * Intent extra — never the password itself, username, or any
 * decrypted sensitive data. Sensitive fields are only ever held in
 * this Activity's local EditText fields and DecryptedPassword objects
 * in memory, never in Intent extras, SharedPreferences, or logs.
 */
public class AddEditPasswordActivity extends AppCompatActivity {

    public static final String EXTRA_PASSWORD_ID = "password_id";
    private static final int NO_ID = -1;

    private TextView screenTitle;
    private EditText siteNameInput;
    private EditText usernameInput;
    private EditText passwordInput;
    private EditText urlInput;
    private EditText notesInput;
    private ImageButton toggleVisibilityButton;
    private ImageButton backButton;
    private Button saveButton;
    private TextView errorText;

    private PasswordRepository passwordRepository;
    private int editingPasswordId = NO_ID;
    private boolean isPasswordVisible = false;

    // Preserved so an update doesn't lose the original creation timestamp
    // or favorite status the user hasn't touched on this screen.
    private long originalCreatedAt = 0;
    private boolean originalIsFavorite = false;
    private int originalCategoryId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_add_edit_password);

        passwordRepository = new PasswordRepository(getApplicationContext());

        bindViews();
        setupListeners();

        editingPasswordId = getIntent().getIntExtra(EXTRA_PASSWORD_ID, NO_ID);
        if (editingPasswordId != NO_ID) {
            loadExistingPassword(editingPasswordId);
        }
    }

    private void bindViews() {
        screenTitle = findViewById(R.id.screenTitle);
        siteNameInput = findViewById(R.id.siteNameInput);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        urlInput = findViewById(R.id.urlInput);
        notesInput = findViewById(R.id.notesInput);
        toggleVisibilityButton = findViewById(R.id.toggleVisibilityButton);
        backButton = findViewById(R.id.backButton);
        saveButton = findViewById(R.id.saveButton);
        errorText = findViewById(R.id.errorText);
    }

    private void setupListeners() {
        backButton.setOnClickListener(v -> finish());
        toggleVisibilityButton.setOnClickListener(v -> togglePasswordVisibility());
        saveButton.setOnClickListener(v -> handleSaveClicked());
    }

    private void loadExistingPassword(int id) {
        screenTitle.setText("Edit Password");
        saveButton.setText("Update Password");

        passwordRepository.getPasswordByIdAsync(id, decrypted -> {
            if (decrypted == null) {
                Toast.makeText(this, "Could not load this entry.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            siteNameInput.setText(decrypted.siteName);
            usernameInput.setText(decrypted.username);
            passwordInput.setText(decrypted.password);
            urlInput.setText(decrypted.url);
            notesInput.setText(decrypted.notes);

            originalCreatedAt = decrypted.createdAt;
            originalIsFavorite = decrypted.isFavorite;
            originalCategoryId = decrypted.categoryId;
        });
    }

    private void togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible;
        int cursorPosition = passwordInput.getSelectionStart();

        if (isPasswordVisible) {
            passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            toggleVisibilityButton.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        } else {
            passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            toggleVisibilityButton.setImageResource(android.R.drawable.ic_menu_view);
        }

        // Restore cursor position so it doesn't jump to the start.
        if (cursorPosition >= 0 && cursorPosition <= passwordInput.getText().length()) {
            passwordInput.setSelection(cursorPosition);
        }
    }

    private void handleSaveClicked() {
        String siteName = siteNameInput.getText().toString().trim();
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        String url = urlInput.getText().toString().trim();
        String notes = notesInput.getText().toString().trim();

        if (siteName.isEmpty()) {
            showError("Please enter a website or app name.");
            return;
        }
        if (password.isEmpty()) {
            showError("Please enter a password.");
            return;
        }

        if (editingPasswordId == NO_ID) {
            passwordRepository.insertPassword(siteName, username, password, url, notes, 0, false);
            Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show();
        } else {
            DecryptedPassword updated = new DecryptedPassword(
                    editingPasswordId, siteName, username, password, url, notes,
                    originalCategoryId, originalIsFavorite, originalCreatedAt,
                    System.currentTimeMillis());
            passwordRepository.updatePassword(updated);
            Toast.makeText(this, "Password updated", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
    }
}


