package com.example.securedigitalvault.ui.photos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.local.entity.PhotoEntity;
import com.example.securedigitalvault.data.repository.PhotoRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * PhotoGridAdapter
 *
 * Displays photo thumbnails. Each item's image is decrypted on demand
 * (not all up front) when it's bound to a visible ViewHolder. Since
 * RecyclerView recycles views during fast scrolling, we tag each
 * ImageView with the photo id it's currently loading for, and only
 * apply the decrypted Bitmap if the view hasn't been recycled for a
 * different item in the meantime.
 */
public class PhotoGridAdapter extends RecyclerView.Adapter<PhotoGridAdapter.PhotoViewHolder> {

    public interface OnPhotoClickListener {
        void onPhotoClick(PhotoEntity photo);
    }

    private List<PhotoEntity> photoList = new ArrayList<>();
    private final PhotoRepository photoRepository;
    private final OnPhotoClickListener clickListener;

    public PhotoGridAdapter(PhotoRepository photoRepository, OnPhotoClickListener clickListener) {
        this.photoRepository = photoRepository;
        this.clickListener = clickListener;
    }

    public void submitList(List<PhotoEntity> newList) {
        this.photoList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_photo_grid, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        PhotoEntity item = photoList.get(position);

        holder.thumbnail.setImageDrawable(null);
        holder.thumbnail.setTag(item.id);

        photoRepository.decryptPhotoByIdAsync(item.id, decrypted -> {
            if (decrypted == null) return;
            // Only apply if this ViewHolder hasn't been recycled for a
            // different item while decryption was happening.
            Object currentTag = holder.thumbnail.getTag();
            if (currentTag instanceof Integer && (Integer) currentTag == item.id) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(
                        decrypted.imageBytes, 0, decrypted.imageBytes.length);
                holder.thumbnail.setImageBitmap(bitmap);
            }
        });

        holder.itemView.setOnClickListener(v -> clickListener.onPhotoClick(item));
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    static class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnail;

        PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.photoThumbnail);
        }
    }
}


