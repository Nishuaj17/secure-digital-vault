package com.example.securedigitalvault.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.SecureNoteDao;
import com.example.securedigitalvault.data.local.entity.SecureNoteEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.ui.notes.DecryptedNote;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SecureNoteRepository {

    public interface NoteCallback {
        void onResult(DecryptedNote note);
    }

    private final SecureNoteDao noteDao;
    private final CryptoManager cryptoManager;
    private final ExecutorService executorService;

    public SecureNoteRepository(Context context) {
        VaultDatabase database = VaultDatabase.getInstance(context);
        this.noteDao = database.secureNoteDao();
        this.cryptoManager = new CryptoManager(new KeystoreManager());
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<DecryptedNote>> getAllNotes() {
        return Transformations.map(noteDao.getAllNotes(), this::decryptList);
    }

    public LiveData<Integer> getNoteCountLive() {
        return noteDao.getNoteCountLive();
    }

    public void insertNote(String title, String content, int categoryId, boolean isFavorite) {
        executorService.execute(() -> {
            long now = System.currentTimeMillis();
            byte[] encryptedContent = cryptoManager.encryptString(content);
            SecureNoteEntity entity = new SecureNoteEntity(
                    title, categoryId, isFavorite, now, now, encryptedContent);
            noteDao.insert(entity);
        });
    }

    public void updateNote(DecryptedNote decrypted) {
        executorService.execute(() -> {
            byte[] encryptedContent = cryptoManager.encryptString(decrypted.content);
            SecureNoteEntity entity = new SecureNoteEntity(
                    decrypted.title, decrypted.categoryId, decrypted.isFavorite,
                    decrypted.createdAt, System.currentTimeMillis(), encryptedContent);
            entity.id = decrypted.id;
            noteDao.update(entity);
        });
    }

    public void deleteNote(int id) {
        executorService.execute(() -> {
            SecureNoteEntity entity = noteDao.getNoteById(id);
            if (entity != null) {
                noteDao.delete(entity);
            }
        });
    }

    public void getNoteByIdAsync(int id, NoteCallback callback) {
        executorService.execute(() -> {
            SecureNoteEntity entity = noteDao.getNoteById(id);
            Handler mainHandler = new Handler(Looper.getMainLooper());

            if (entity == null) {
                mainHandler.post(() -> callback.onResult(null));
                return;
            }

            String content = cryptoManager.decryptToString(entity.encryptedContent);
            DecryptedNote decrypted = new DecryptedNote(
                    entity.id, entity.title, content, entity.categoryId,
                    entity.isFavorite, entity.createdAt, entity.updatedAt);

            mainHandler.post(() -> callback.onResult(decrypted));
        });
    }

    private List<DecryptedNote> decryptList(List<SecureNoteEntity> entities) {
        List<DecryptedNote> result = new ArrayList<>();
        for (SecureNoteEntity entity : entities) {
            String content = cryptoManager.decryptToString(entity.encryptedContent);
            result.add(new DecryptedNote(entity.id, entity.title, content, entity.categoryId,
                    entity.isFavorite, entity.createdAt, entity.updatedAt));
        }
        return result;
    }
    public void toggleFavorite(int id, boolean isFavorite) {
        executorService.execute(() -> noteDao.updateFavoriteStatus(id, isFavorite));
    }
}


