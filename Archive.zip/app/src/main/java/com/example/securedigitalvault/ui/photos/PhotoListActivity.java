package com.example.securedigitalvault.ui.photos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.local.entity.PhotoEntity;
import com.example.securedigitalvault.data.repository.PhotoRepository;
import com.example.securedigitalvault.util.SecurityUtils;

/**
 * PhotoListActivity
 *
 * Displays the encrypted photo grid and lets the user import new
 * photos using Android's modern Photo Picker
 * (ActivityResultContracts.PickVisualMedia). The Photo Picker is a
 * system UI that grants the app temporary, scoped access to only the
 * specific photo the user selects — it does NOT require the broad
 * READ_EXTERNAL_STORAGE / READ_MEDIA_IMAGES permission, which is a
 * meaningful privacy benefit of using this modern API.
 */
public class PhotoListActivity extends AppCompatActivity implements PhotoGridAdapter.OnPhotoClickListener {

    private RecyclerView recyclerView;
    private android.widget.TextView emptyStateText;
    private PhotoRepository photoRepository;
    private PhotoGridAdapter adapter;

    private ActivityResultLauncher<PickVisualMediaRequest> photoPickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_photo_list);

        photoRepository = new PhotoRepository(getApplicationContext());

        recyclerView = findViewById(R.id.photoRecyclerView);
        emptyStateText = findViewById(R.id.emptyStateText);

        adapter = new PhotoGridAdapter(photoRepository, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        recyclerView.setAdapter(adapter);

        registerPhotoPicker();

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.importButton).setOnClickListener(v ->
                photoPickerLauncher.launch(new PickVisualMediaRequest.Builder()
                        .setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE)
                        .build()));

        photoRepository.getAllPhotoMetadata().observe(this, photos -> {
            adapter.submitList(photos);
            emptyStateText.setVisibility(photos.isEmpty() ? View.VISIBLE : View.GONE);
            recyclerView.setVisibility(photos.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }

    private void registerPhotoPicker() {
        photoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.PickVisualMedia(),
                selectedUri -> {
                    if (selectedUri == null) {
                        // User backed out of the picker without selecting anything.
                        return;
                    }
                    Toast.makeText(this, "Encrypting and saving photo...", Toast.LENGTH_SHORT).show();
                    photoRepository.insertPhoto(selectedUri, success -> {
                        String message = success ? "Photo saved securely" : "Failed to save photo";
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    });
                });
    }

    @Override
    public void onPhotoClick(PhotoEntity photo) {
        Intent intent = new Intent(this, PhotoViewerActivity.class);
        intent.putExtra(PhotoViewerActivity.EXTRA_PHOTO_ID, photo.id);
        startActivity(intent);
    }
}

