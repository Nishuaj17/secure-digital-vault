package com.example.securedigitalvault.data.repository;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;

import androidx.lifecycle.LiveData;

import com.example.securedigitalvault.data.local.VaultDatabase;
import com.example.securedigitalvault.data.local.dao.DocumentFileDao;
import com.example.securedigitalvault.data.local.entity.DocumentFileEntity;
import com.example.securedigitalvault.security.CryptoManager;
import com.example.securedigitalvault.security.KeystoreManager;
import com.example.securedigitalvault.security.SecureFileManager;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DocumentFileRepository
 *
 * Coordinates PDF/document metadata (Room) with encrypted file storage
 * (SecureFileManager). Handles the full lifecycle: import + encrypt,
 * decrypt-to-temp-file for viewing, and cleanup of that temp file.
 */
public class DocumentFileRepository {

    public interface ImportCallback {
        void onComplete(boolean success);
    }

    public interface OpenCallback {
        void onReady(File tempFile);
        void onError();
    }

    // How long a decrypted temp copy is allowed to exist before being
    // automatically deleted, even if the user never returns to the app.
    private static final long TEMP_FILE_LIFETIME_MILLIS = 2 * 60 * 1000; // 2 minutes

    private final Context appContext;
    private final DocumentFileDao documentFileDao;
    private final SecureFileManager secureFileManager;
    private final ExecutorService executorService;

    public DocumentFileRepository(Context context) {
        this.appContext = context.getApplicationContext();
        VaultDatabase database = VaultDatabase.getInstance(appContext);
        this.documentFileDao = database.documentFileDao();
        CryptoManager cryptoManager = new CryptoManager(new KeystoreManager());
        this.secureFileManager = new SecureFileManager(cryptoManager);
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<DocumentFileEntity>> getAllDocuments() {
        return documentFileDao.getAllDocuments();
    }

    public LiveData<List<DocumentFileEntity>> searchByFileName(String term) {
        return documentFileDao.searchByFileName(term);
    }

    public LiveData<Integer> getDocumentCountLive() {
        return documentFileDao.getDocumentCountLive();
    }

    public void insertDocument(Uri sourceUri, ImportCallback callback) {
        executorService.execute(() -> {
            boolean success = true;
            try {
                String displayName = queryDisplayName(sourceUri);
                long sizeBytes = querySize(sourceUri);
                String fileType = extractFileExtension(displayName);

                String encryptedFileName = secureFileManager.encryptAndStoreFile(
                        appContext, sourceUri, SecureFileManager.DIR_DOCUMENTS);

                DocumentFileEntity entity = new DocumentFileEntity(
                        displayName, fileType, sizeBytes, encryptedFileName, 0,
                        System.currentTimeMillis());
                documentFileDao.insert(entity);

            } catch (IOException e) {
                success = false;
            }
            boolean finalSuccess = success;
            new Handler(Looper.getMainLooper()).post(() -> callback.onComplete(finalSuccess));
        });
    }

    public void deleteDocument(int id) {
        executorService.execute(() -> {
            DocumentFileEntity entity = documentFileDao.getDocumentById(id);
            if (entity != null) {
                secureFileManager.deleteEncryptedFile(appContext, entity.encryptedFileName,
                        SecureFileManager.DIR_DOCUMENTS);
                documentFileDao.delete(entity);
            }
        });
    }

    /**
     * Decrypts a document into a short-lived temp file for viewing,
     * then schedules that temp file's deletion after a fixed window —
     * even if the user never comes back to explicitly close the viewer.
     */
    public void openDocumentSecurely(int id, OpenCallback callback) {
        executorService.execute(() -> {
            DocumentFileEntity entity = documentFileDao.getDocumentById(id);
            Handler mainHandler = new Handler(Looper.getMainLooper());

            if (entity == null) {
                mainHandler.post(callback::onError);
                return;
            }

            try {
                File tempFile = secureFileManager.decryptToTempFile(
                        appContext, entity.encryptedFileName, SecureFileManager.DIR_DOCUMENTS,
                        entity.fileName);

                mainHandler.post(() -> callback.onReady(tempFile));

                // Schedule automatic cleanup regardless of what the user
                // does next, so a decrypted copy never lingers indefinitely.
                mainHandler.postDelayed(() -> {
                    if (tempFile.exists()) {
                        tempFile.delete();
                    }
                }, TEMP_FILE_LIFETIME_MILLIS);

            } catch (IOException e) {
                mainHandler.post(callback::onError);
            }
        });
    }

    /**
     * Deletes any leftover temp decrypted files. Call this on app
     * startup and whenever the vault locks, so no decrypted copy can
     * survive across app sessions.
     */
    public void clearTempFiles() {
        secureFileManager.clearAllTempFiles(appContext);
    }

    private String queryDisplayName(Uri uri) {
        ContentResolver resolver = appContext.getContentResolver();
        try (Cursor cursor = resolver.query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    return cursor.getString(nameIndex);
                }
            }
        }
        return "document";
    }

    private long querySize(Uri uri) {
        ContentResolver resolver = appContext.getContentResolver();
        try (Cursor cursor = resolver.query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                    return cursor.getLong(sizeIndex);
                }
            }
        }
        return 0;
    }

    private String extractFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == fileName.length() - 1) {
            return "file";
        }
        return fileName.substring(dotIndex + 1).toUpperCase();
    }
}

