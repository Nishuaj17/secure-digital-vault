package com.example.securedigitalvault.ui.photos;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.securedigitalvault.R;
import com.example.securedigitalvault.data.repository.PhotoRepository;
import com.example.securedigitalvault.util.SecurityUtils;

/**
 * PhotoViewerActivity
 *
 * Displays one photo full-screen after decrypting it directly into
 * memory. No decrypted file is ever written to disk — the Bitmap
 * exists only in this Activity's memory for as long as the screen is
 * visible, and is released when the Activity is destroyed.
 */
public class PhotoViewerActivity extends AppCompatActivity {

    public static final String EXTRA_PHOTO_ID = "photo_id";

    private PhotoRepository photoRepository;
    private int photoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SecurityUtils.applySecureFlag(this);
        setContentView(R.layout.activity_photo_viewer);

        photoRepository = new PhotoRepository(getApplicationContext());
        photoId = getIntent().getIntExtra(EXTRA_PHOTO_ID, -1);

        ImageView fullPhotoView = findViewById(R.id.fullPhotoView);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.deleteButton).setOnClickListener(v -> confirmDelete());

        photoRepository.decryptPhotoByIdAsync(photoId, decrypted -> {
            if (decrypted == null) {
                Toast.makeText(this, "Could not load this photo.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            Bitmap bitmap = BitmapFactory.decodeByteArray(
                    decrypted.imageBytes, 0, decrypted.imageBytes.length);
            fullPhotoView.setImageBitmap(bitmap);
        });
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Delete this photo?")
                .setMessage("This will permanently delete the photo. This cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    photoRepository.deletePhoto(photoId);
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}


